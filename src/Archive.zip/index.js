var APP_ID = undefined;

var http       = require('http')
  , AlexaSkill = require('./AlexaSkill')

var handlePersonInfoRequest = function(intent, session, response){
    var person = intent.slots.person.value;
    console.log("Person is " + person);
    var cardText = "The person you asked about is " + person;
    response.tellWithCard("That person does not exist", "Person Info", cardText);
}


var PersonInfo = function(){
  AlexaSkill.call(this, APP_ID);
};

PersonInfo.prototype = Object.create(AlexaSkill.prototype);
PersonInfo.prototype.constructor = PersonInfo;

PersonInfo.prototype.eventHandlers.onSessionStarted = function(sessionStartedRequest, session){
    console.log("onSessionStarted requestId: " + sessionStartedRequest.requestId
      + ", sessionId: " + session.sessionId);
};

PersonInfo.prototype.eventHandlers.onLaunch = function(launchRequest, session, response){
  var output = 'Welcome to PersonInfo. ' +
    'Which Person do you want to know more about.';

  var reprompt = 'Which person do you want to know more about?';

  response.ask(output, reprompt);

  console.log("onLaunch requestId: " + launchRequest.requestId
      + ", sessionId: " + session.sessionId);
};

PersonInfo.prototype.intentHandlers = {
  GetPersonIntent: function(intent, session, response){
    handlePersonInfoRequest(intent, session, response);
  },

  HelpIntent: function(intent, session, response){
    var speechOutput = 'Get info on anyone in the Barstow family';
    response.ask(speechOutput);
  }
};


exports.handler = (event, context, callback) => {
    var skill = new PersonInfo();
    skill.execute(event, context);
};